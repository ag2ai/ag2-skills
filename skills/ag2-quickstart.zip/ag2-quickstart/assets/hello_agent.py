"""Hello Agent — minimal AG2 example.

Mirrors website/docs/user-guide/code_examples/01_hello_agent.mdx. The smallest
possible end-to-end: instantiate an Agent with one model config, call ask(),
print the reply, then reuse the same Agent for a second turn.

Run::

    python hello_agent.py
"""

import asyncio

from dotenv import load_dotenv

from ag2 import Agent
from ag2.config import GeminiConfig

# Load API keys from a .env file at the project root (GEMINI_API_KEY here).
# Swap GeminiConfig for OpenAIResponsesConfig / AnthropicConfig if that's the key you have
# (drop temperature= for AnthropicConfig — deprecated there).
load_dotenv()


def section(title: str) -> None:
    print(f"\n── {title} ───")


async def main() -> None:
    config = GeminiConfig(model="gemini-3.6-flash", temperature=0)

    section("Bare Agent — ask and print")

    agent = Agent(
        "greeter",
        prompt="You are a friendly but concise assistant. Reply in one sentence.",
        config=config,
    )

    reply = await agent.ask("Give me a single tip for learning to play chess.")
    print(reply.body)

    section("Reuse the Agent for another ask")

    reply2 = await agent.ask("And a tip for learning poker, in one sentence.")
    print(reply2.body)


if __name__ == "__main__":
    asyncio.run(main())
